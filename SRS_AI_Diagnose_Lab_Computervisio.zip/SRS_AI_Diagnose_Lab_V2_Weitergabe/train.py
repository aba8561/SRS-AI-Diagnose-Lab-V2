"""Reproducible synthetic warning-symbol classifier training & evaluation."""
import json
from pathlib import Path
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from joblib import dump
from srs_lab.vision import LABELS,make_symbol,vectorize

P=Path(__file__).resolve().parent

def train():
    X=[]; y=[]
    for label in LABELS:
        for idx in range(140):
            im=make_symbol(label, (LABELS.index(label)+1)*10000+idx)
            X.append(vectorize(im)); y.append(label)
    X=np.array(X); y=np.array(y)
    Xtrain,Xtest,ytrain,ytest=train_test_split(X,y,test_size=.25,random_state=27,stratify=y)
    clf=LogisticRegression(max_iter=1500,C=3.0,random_state=27)
    clf.fit(Xtrain,ytrain)
    preds=clf.predict(Xtest)
    report=classification_report(ytest,preds,output_dict=True,zero_division=0)
    result={"scope":"nur synthetische Icons, keine echte Fahrzeugbild-Evaluation",
      "train":int(len(ytrain)),"test":int(len(ytest)),
      "accuracy":round(float(report["accuracy"]),4),
      "macro_f1":round(float(report["macro avg"]["f1-score"]),4),
      "class_report":report,
      "labels":LABELS,
      "confusion_matrix":confusion_matrix(ytest,preds,labels=LABELS).tolist()}
    (P/"models").mkdir(exist_ok=True)
    dump(clf,P/"models"/"warning_classifier.joblib",compress=3)
    (P/"models"/"metrics.json").write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("class_report","confusion_matrix")},ensure_ascii=False,indent=2))
    for label in LABELS:
        make_symbol(label,777+LABELS.index(label)).save(P/"examples"/f"demo_{label}.png")
    return result
if __name__=="__main__":train()
