"""Tiny supervised ML classifier for synthetic dashboard symbols. Input must be cropped."""
import io, math, random
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from joblib import load
from functools import lru_cache
from .catalog import LIGHTS

LABELS=["abs","airbag","battery","brake","engine","oil","seatbelt","unknown"]
ROOT=Path(__file__).resolve().parent.parent

def font(n):
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/arial.ttf"]:
        try: return ImageFont.truetype(p,n)
        except OSError: pass
    return ImageFont.load_default()

def make_symbol(kind, seed=0):
    rng=random.Random(seed)
    n=80
    bg=rng.randint(2,20)
    im=Image.new("RGB",(n,n),(bg,bg,bg))
    color=rng.choice([(255,178,0),(250,57,50),(240,235,75),(235,235,235)])
    d=ImageDraw.Draw(im)
    shift=rng.randint(-4,4)
    # illustration-only; stylized diagrams, not standardized OEM pictograms
    if kind=="abs":
        d.ellipse((9+shift,8,71+shift,70),outline=color,width=3)
        d.text((16+shift,24),"ABS",font=font(22),fill=color)
    elif kind=="brake":
        d.ellipse((15+shift,9,65+shift,69),outline=color,width=4)
        d.text((33+shift,19),"!",font=font(33),fill=color)
        d.arc((4+shift,5,76+shift,73),110,250,fill=color,width=3)
    elif kind=="airbag":
        d.ellipse((13+shift,12,25+shift,25),fill=color)
        d.line((20+shift,28,26+shift,53),fill=color,width=5)
        d.line((26+shift,45,40+shift,61),fill=color,width=5)
        d.line((19+shift,46,10+shift,58),fill=color,width=5)
        d.ellipse((43+shift,28,67+shift,53),outline=color,width=4)
        d.line((30+shift,48,42+shift,45),fill=color,width=3)
    elif kind=="seatbelt":
        d.ellipse((28+shift,10,42+shift,24),fill=color)
        d.line((35+shift,25,35+shift,53),fill=color,width=5)
        d.line((20+shift,38,52+shift,62),fill=color,width=5)
        d.line((52+shift,24,24+shift,62),fill=color,width=5)
    elif kind=="battery":
        d.rectangle((12+shift,24,67+shift,56),outline=color,width=4)
        d.rectangle((18+shift,18,26+shift,23),fill=color)
        d.rectangle((52+shift,18,60+shift,23),fill=color)
        d.line((26+shift,39,38+shift,39),fill=color,width=3)
        d.line((52+shift,33,52+shift,46),fill=color,width=3)
        d.line((45+shift,39,59+shift,39),fill=color,width=3)
    elif kind=="oil":
        d.polygon([(10+shift,36),(43+shift,26),(59+shift,42),(48+shift,53),(19+shift,53)],outline=color)
        d.line((20+shift,29,39+shift,29),fill=color,width=5)
        d.line((57+shift,45,68+shift,41),fill=color,width=4)
        d.ellipse((62+shift,52,69+shift,61),fill=color)
    elif kind=="engine":
        d.rectangle((16+shift,26,59+shift,56),outline=color,width=4)
        d.rectangle((26+shift,18,42+shift,28),fill=color)
        d.line((9+shift,33,16+shift,33),fill=color,width=4)
        d.line((59+shift,48,71+shift,48),fill=color,width=4)
    else:
        for _ in range(3):
            x,y=rng.randint(13,60),rng.randint(12,64)
            d.line((x,y,x+rng.randint(-12,12),y+rng.randint(-10,10)), fill=color,width=3)
    if rng.random() < 0.35: im=im.filter(ImageFilter.GaussianBlur(rng.uniform(0,.7)))
    im=im.rotate(rng.uniform(-13,13),resample=Image.Resampling.BILINEAR, fillcolor=(bg,bg,bg))
    a=np.asarray(im).astype(np.float32)
    noise=np.random.default_rng(seed).normal(0,rng.uniform(1,8),a.shape)
    return Image.fromarray(np.uint8(np.clip(a+noise,0,255)))

def vectorize(im):
    """Bright foreground mask, 20x20 pooled intensity + contrast features."""
    im=im.convert("RGB").resize((80,80),Image.Resampling.LANCZOS)
    a=np.asarray(im).astype(np.float32)
    l=a.max(axis=2)
    # Defocus background: prominent bright pixels of dashboard symbol, regardless of hue.
    mask=np.clip((l-28)/110,0,1)
    blocks=mask.reshape(20,4,20,4).mean(axis=(1,3))
    # Include relative vertical / horizontal edges to aid geometric discrimination.
    dx=np.diff(blocks,axis=1,prepend=blocks[:,0:1]); dy=np.diff(blocks,axis=0,prepend=blocks[0:1,:])
    return np.concatenate([blocks.ravel(), np.abs(dx).ravel(), np.abs(dy).ravel()]).astype(np.float32)

@lru_cache(maxsize=1)
def model():
    p=ROOT/"models"/"warning_classifier.joblib"
    if not p.exists(): raise FileNotFoundError("Modell fehlt. Zuerst: python train.py")
    return load(p)  # load only your own trusted local model

def predict_image(im):
    clf=model(); v=vectorize(im).reshape(1,-1)
    probs=clf.predict_proba(v)[0]
    pairs=sorted(zip(clf.classes_,probs),key=lambda x:x[1],reverse=True)
    raw=pairs[0][0]; p=float(pairs[0][1])
    margin = p - float(pairs[1][1]) if len(pairs) > 1 else p
    # Conservative abstention, not a guarantee of real-world correctness.
    label = str(raw) if p >= 0.88 and margin >= 0.35 else "unknown"
    return {"label":label,"label_de":LIGHTS.get(label),
        "confidence":round(p,3), "raw_top_class":str(raw),
        "decision":"Nur Modellvorschlag; immer manuell bestaetigen" if label != 'unknown' else "Unsicher – bitte Symbol manuell waehlen",
        "model_score_not_calibrated":True, "human_confirmation_required":True,
        "real_image_accuracy_validated":False,
        "top3":[{"label":str(k),"prob":round(float(s),3)} for k,s in pairs[:3]],
        "warning":("Konfidenz ist nur ein unkalibrierter Modellscore. Nur synthetische Trainingsbilder. Echte Fotos sind NICHT validiert; "
                   "Warnsymbol manuell bestätigen. Kein Rückschluss auf DTC oder Ursache.")}
