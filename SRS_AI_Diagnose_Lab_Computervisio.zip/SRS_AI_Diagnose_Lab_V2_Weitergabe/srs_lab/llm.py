"""Strictly opt-in Azure OpenAI adapter; unavailable by default.

Do not send real vehicle/customer data. Uses only synthetic demo cases.
"""
import os
import httpx

BASE_RULES = (
    'Du fasst eine ausschließlich synthetische Automotive-Lehrfallanalyse zusammen. '
    'Berichte in deutscher Sprache. Verwende nur die übergebenen Belege. '
    'Keine Fakten, DTC-Definitionen oder OEM-Verfahren erfinden. '
    'Keine Anleitungen für Eingriffe an Airbags, Zündkreisen, Codierung oder HV-Systemen. '
    'Nenne immer die Quellen-IDs. Erkläre ausdrücklich, dass dies keine Fahrzeugdiagnose ist. '
    'Falls Angaben fehlen, benenne sie. Halte dich unter 220 Wörtern.'
)


def configured():
    return all(os.getenv(x, '').strip() for x in (
        'AZURE_OPENAI_ENDPOINT','AZURE_OPENAI_API_KEY','AZURE_OPENAI_DEPLOYMENT'))


def summarize(report: dict) -> str:
    if not configured():
        raise RuntimeError('Azure OpenAI nicht konfiguriert; regelbasierter Bericht bleibt verfügbar.')
    endpoint = os.environ['AZURE_OPENAI_ENDPOINT'].strip().rstrip('/')
    if not endpoint.startswith('https://') or not endpoint.endswith('.openai.azure.com'):
        raise RuntimeError('AZURE_OPENAI_ENDPOINT muss https://<resource>.openai.azure.com sein.')
    deployment = os.environ['AZURE_OPENAI_DEPLOYMENT']
    # Minimize outbound data. Never include uploaded images, raw CSV, user note or arbitrary text.
    dtcs=[{"component":d['component'],"fault_type":d['fault_type'],
           "hypotheses":[e['finding'] for e in d['evidence']]} for d in report['dtc_analysis'][:8]]
    refs=[{"id":r['id'],"title":r['title'],"text":r['extract'][:360]} for r in report['references'][:4]]
    payload={"model":deployment, "messages":[{"role":"system","content":BASE_RULES},
       {"role":"user","content":str({"light":report['light_name'],"cases":dtcs,"sources":refs})}],
       "temperature":0, "max_tokens":380}
    try:
        with httpx.Client(timeout=18.0,follow_redirects=False) as client:
            res=client.post(endpoint+'/openai/v1/chat/completions',
                headers={'api-key':os.environ['AZURE_OPENAI_API_KEY'], 'Content-Type':'application/json'},
                json=payload)
            res.raise_for_status()
            content=res.json()['choices'][0]['message']['content']
            if not isinstance(content,str) or not content.strip():
                raise RuntimeError('LLM hat keinen nutzbaren Text geliefert.')
            return content[:3500]
    except (httpx.HTTPError,KeyError,IndexError,TypeError,ValueError) as e:
        raise RuntimeError('Azure-LLM nicht erreichbar oder Antwort ungültig. Lokalbericht bleibt erhalten.') from e
