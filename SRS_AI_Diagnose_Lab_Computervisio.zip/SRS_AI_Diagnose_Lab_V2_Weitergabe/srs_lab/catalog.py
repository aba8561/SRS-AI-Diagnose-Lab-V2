"""Synthetic demo catalog. NO manufacturer's fault-code definitions."""
COMPONENTS = {
    "driver_front_airbag": ("Fahrer-Frontairbag", "Fahrzeugsicherheit / SRS"),
    "passenger_front_airbag": ("Beifahrer-Frontairbag", "Fahrzeugsicherheit / SRS"),
    "driver_knee_airbag": ("Fahrer-Knieairbag", "Fahrzeugsicherheit / SRS"),
    "passenger_knee_airbag": ("Beifahrer-Knieairbag", "Fahrzeugsicherheit / SRS"),
    "driver_side_airbag": ("Fahrer-Seitenairbag", "Fahrzeugsicherheit / SRS"),
    "passenger_side_airbag": ("Beifahrer-Seitenairbag", "Fahrzeugsicherheit / SRS"),
    "left_curtain_airbag": ("Kopfairbag links", "Fahrzeugsicherheit / SRS"),
    "right_curtain_airbag": ("Kopfairbag rechts", "Fahrzeugsicherheit / SRS"),
    "driver_pretensioner": ("Gurtstraffer Fahrer", "Fahrzeugsicherheit / SRS"),
    "passenger_pretensioner": ("Gurtstraffer Beifahrer", "Fahrzeugsicherheit / SRS"),
    "rear_left_pretensioner": ("Gurtstraffer hinten links", "Fahrzeugsicherheit / SRS"),
    "rear_right_pretensioner": ("Gurtstraffer hinten rechts", "Fahrzeugsicherheit / SRS"),
    "driver_buckle": ("Gurtschloss Fahrer", "Fahrzeugsicherheit / SRS"),
    "passenger_buckle": ("Gurtschloss Beifahrer", "Fahrzeugsicherheit / SRS"),
    "rear_buckle": ("Gurtschloss hinten", "Fahrzeugsicherheit / SRS"),
    "seat_belt_reminder": ("SBR / Gurtwarnung", "Fahrzeugsicherheit / SRS + Karosserie"),
    "occupant_sensor": ("Sitzbelegungserkennung", "Fahrzeugsicherheit / SRS + Sitzsysteme"),
    "crash_sensor_front": ("Crashsensor vorn", "Fahrzeugsicherheit / SRS"),
    "crash_sensor_side": ("Crashsensor seitlich", "Fahrzeugsicherheit / SRS"),
    "srs_control_unit": ("Airbag-Steuergerät", "Fahrzeugsicherheit / SRS + E/E Integration"),
    "ecall_module": ("eCall-Steuergerät", "Telematik / eCall + Fahrzeugsicherheit"),
    "pwm_interface": ("PWM-Schnittstelle", "E/E Integration + zuständiges Komponenten-Team"),
    "can_interface": ("CAN-Kommunikation", "E/E Integration / Fahrzeugnetzwerk"),
    "hv_crash_cutoff": ("Crash-HV-Abschaltung", "Hochvolt-Sicherheit + Fahrzeugsicherheit"),
    "power_supply": ("Versorgung SRS", "E/E Integration + Fahrzeugsicherheit"),
}
FAULT_TYPES = {
    "resistance_high": "Widerstand zu hoch / Unterbrechung möglich",
    "resistance_low": "Widerstand zu niedrig / Kurzschluss möglich",
    "invalid_dataset": "Datensatz ungültig / nicht kompatibel",
    "coding_mismatch": "Codierung und Ausstattung stimmen möglicherweise nicht überein",
    "communication_timeout": "Kommunikation unterbrochen / Timeout",
    "implausible_signal": "Signalwert unplausibel",
    "voltage_low": "Spannungsversorgung zu niedrig",
    "voltage_high": "Spannungsversorgung zu hoch",
    "intermittent": "Sporadischer Fehler",
    "internal_fault": "Steuergeräteinterner Fehler",
    "sensor_fault": "Sensorfehler",
    "unknown": "Unbekannter Fehlercode / keine Zuordnung",
}
LIGHTS = {
 "airbag":"Airbag-/SRS-Warnlampe", "abs":"ABS-Warnlampe", "brake":"Brems-Warnlampe",
 "seatbelt":"Gurtwarnung", "oil":"Öldruck-Warnlampe", "battery":"Ladesystem-Warnlampe",
 "engine":"Motorkontrollleuchte", "unknown":"Nicht sicher erkannt"
}
DEPARTMENTS = {"airbag":"Fahrzeugsicherheit / SRS", "seatbelt":"Fahrzeugsicherheit / SRS", "abs":"Bremsregelsysteme / Fahrdynamik", "brake":"Bremssysteme", "oil":"Antrieb / Schmierung", "battery":"Bordnetz / Energieversorgung", "engine":"Antrieb / Motorsteuerung", "unknown":"Diagnosekoordination"}
