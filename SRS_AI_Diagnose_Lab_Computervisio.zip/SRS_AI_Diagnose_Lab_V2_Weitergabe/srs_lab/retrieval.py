"""Explainable hybrid retrieval over curated fictitious teaching documents.

A DTC type is a *trusted structured field*, not an inferred property from an image.
Metadata matching protects relevance when question wording varies German/English.
"""
from functools import lru_cache
from pathlib import Path
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT = Path(__file__).resolve().parent.parent

@lru_cache(maxsize=1)
def index():
    documents = json.loads((ROOT/'data'/'knowledge_v2.json').read_text(encoding='utf-8'))
    vectorizer = TfidfVectorizer(ngram_range=(1,2), lowercase=True, sublinear_tf=True, strip_accents='unicode')
    matrix = vectorizer.fit_transform([f"{d['title']} {d['title']} {d['text']} {' '.join(d['keywords'])}" for d in documents])
    return documents, vectorizer, matrix


def search(question: str = '', dtcs: list[dict] | None = None, k: int = 5) -> list[dict]:
    docs, vectorizer, matrix = index()
    dtcs = dtcs or []
    # Enrich user question with high-information technical labels.
    types = {d.get('type','') for d in dtcs}
    components = {d.get('component','') for d in dtcs}
    q = (str(question or '') + ' ' + ' '.join(types) + ' ' + ' '.join(components)).strip()[:2500]
    if not q:
        q = 'Airbag SRS Fehlerspeicher Safety Diagnose'
    similarities = cosine_similarity(vectorizer.transform([q]), matrix)[0]
    ranked=[]
    for i,d in enumerate(docs):
        metadata_type = 0.45 if (types & set(d.get('types',[]))) else 0.0
        metadata_component = 0.10 if (components & set(d.get('components',[]))) else 0.0
        # Broad SRS documents should not outrank specific DTC documents.
        score = round(float(similarities[i]) + metadata_type + metadata_component, 4)
        if score >= 0.045:
            ranked.append((score,i))
    ranked.sort(key=lambda si:(-si[0],docs[si[1]]['id']))
    return [{"id":docs[i]['id'],"title":docs[i]['title'],"extract":docs[i]['text'],
             "score":s,"matched_dtc_types":sorted(types & set(docs[i].get('types',[]))),
             "source_kind":"Synthetisches Lehrdokument – keine OEM-Quelle"}
            for s,i in ranked[:max(1,min(k,10))]]
