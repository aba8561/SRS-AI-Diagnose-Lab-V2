"""Explainable risk-averse triage. Not a diagnostic device or vehicle controller."""
from dataclasses import dataclass, asdict
from .catalog import COMPONENTS, FAULT_TYPES, LIGHTS, DEPARTMENTS

SAFETY = ("DEMO / keine Fahrzeugfreigabe: SRS-Bauteile nicht elektrisch sondieren, "
          "überbrücken, codieren oder auslösen. Nur freigegebene OEM-Diagnose- "
          "und Sicherheitsabläufe durch qualifizierte Fachkräfte.")

@dataclass
class Evidence:
    rule: str
    finding: str
    action: str
    confidence: str


def classify_dtc(entry: dict, configuration: dict | None = None) -> dict:
    """Careful hypotheses, never convert a generic DTC into a certain root cause."""
    configuration = configuration or {}
    kind = str(entry.get("type", "unknown"))
    part = str(entry.get("component", "srs_control_unit"))
    part_label, team = COMPONENTS.get(part, ("Unbekanntes Bauteil", "Diagnosekoordination / E/E"))
    desc = FAULT_TYPES.get(kind, FAULT_TYPES["unknown"])
    coded = configuration.get("coded", "unknown")
    installed = configuration.get("installed", "unknown")
    e = []
    if kind == "resistance_high":
        e.append(Evidence("R-HIGH", "Unterbrechung/offene Leitung, Steckkontakt oder hoher Übergangswiderstand sind MÖGLICHE Ursachen.",
             "DTC-Umgebungsdaten, eindeutige betroffene Stromkreis-ID und OEM-Prüfablauf anfordern.", "Hypothese"))
        if coded is True and installed is False:
            e.append(Evidence("CFG-POSSIBLE", "Konfigurationsabweichung denkbar: codiert, aber laut Angabe nicht verbaut.",
                 "Ausstattungs-/Zieldatenstand mit freigegebener Variantenliste prüfen; kein automatisches Umcodieren.", "Kontextabhängig"))
    elif kind == "resistance_low":
        e.append(Evidence("R-LOW", "Niedriger Stromkreiswiderstand oder Kurzschluss sind MÖGLICHE Ursachen.",
             "Betroffenen Stromkreis anhand OEM-Fehlerbeschreibung eingrenzen; keine Messung an Zündkreisen ohne Freigabe.", "Hypothese"))
        if installed is True and coded is False:
            e.append(Evidence("CFG-CHECK", "Zusätzlich liegt eine gemeldete Ausstattungs-/Codierungsabweichung vor.",
                 "Diese separat prüfen; sie erklärt NICHT automatisch den niedrigen Widerstand.", "Kontextabhängig"))
    elif kind == "invalid_dataset":
        e.append(Evidence("DATASET", "Möglicher unvollständiger, inkompatibler oder nicht freigegebener Datensatz.",
             "HW-/SW-Stand, Zieldatencontainer, Versionsfreigaben und Programmierprotokoll vergleichen.", "Hypothese"))
    elif kind == "coding_mismatch":
        e.append(Evidence("VARIANT", "Mögliche Inkonsistenz zwischen Fahrzeugausstattung und Steuergerätevariante.",
             "ZDC/Variantenkonfiguration mit Stückliste und freigegebenem Fahrzeugauftrag abgleichen.", "Hypothese"))
    elif kind == "communication_timeout":
        e.append(Evidence("NETWORK", "Netzwerk-, Versorgungs- oder Kommunikationsproblem möglich.",
             "CAN-/Netzwerk-Topologie, weitere DTCs, Bordnetzversorgung und Zeitstempel vergleichen.", "Hypothese"))
    elif kind in ("voltage_low", "voltage_high"):
        e.append(Evidence("SUPPLY", "Versorgungsspannung außerhalb des erwarteten Bereichs möglich.",
             "Versorgungsdaten, Zeitstempel und relevante Bordnetzereignisse in freigegebenen Logs prüfen.", "Hypothese"))
    elif kind == "internal_fault":
        e.append(Evidence("ECU-INTERNAL", "Ein intern gemeldeter ECU-Fehler muss mit der spezifischen OEM-Fehlerdefinition eingeordnet werden.",
             "HW-/SW-Stand, DTC-Status und freigegebenes Diagnoseprotokoll an das ECU-Fachteam geben.", "Hypothese"))
    elif kind in ("sensor_fault", "implausible_signal", "intermittent"):
        e.append(Evidence("SIGNAL", "Sensor-, Plausibilitäts-, Kontakt- oder Signalproblem möglich.",
             "Fehlerhäufigkeit, Zeitbezug, Signalstatus und passende Freigabedokumente vergleichen.", "Hypothese"))
    else:
        e.append(Evidence("UNMAPPED", "Kein belastbarer Root-Cause-Nachweis aus diesem generischen Code.",
             "OEM-DTC-Definition und qualifizierte Analyse anfordern.", "Unbestimmt"))
    return {"code": str(entry.get("code", "DEMO-UNSPECIFIED")), "status": str(entry.get("status", "unknown")), "component": part_label,
        "component_id": part, "fault_type": kind, "description":desc,"department":team,
        "evidence":[asdict(x) for x in e], "needs_oem_definition":True}


def triage(light: str, dtcs: list[dict] | None = None, configuration: dict | None = None):
    light = light if light in LIGHTS else "unknown"
    dtcs = (dtcs or [])[:100]
    relevant = [classify_dtc(d, configuration) for d in dtcs]
    if light in ("airbag", "seatbelt"):
        required = ["Fehlerspeicher des Airbag-/SRS-Steuergeräts samt Status und Zeitstempeln",
          "HW-/SW-/Codier-/Datensatzstand und Fahrzeugvariante (ZDC falls vorhanden)",
          "SRS-Komponenten-/Ausstattungsliste (Front-, Seiten-, Kopf-, Knieairbags; Gurtstraffer/Gurtschlösser/SBR)",
          "Begleitfehler / Versorgungs- und Kommunikations-DTCs", "OEM-Prüfvorgaben und Sicherheitsfreigabe"]
    else:
        required = ["Vollständiger Fehlerspeicher des zuständigen Steuergeräts",
          "Fahrzeugvariante, HW-/SW-Stand und Kontext des Auftretens", "OEM-Prüfvorgaben"]
    return {"status":"DEMO – Triage, keine Diagnose oder Reparaturanweisung",
        "light":light,"light_name":LIGHTS[light],"routing":DEPARTMENTS[light],
        "message": "Die Warnlampe zeigt eine mögliche Systemstörung, nicht den defekten Einzelbauteil.",
        "requested_evidence":required,"dtc_analysis":relevant,
        "departments":sorted(set([DEPARTMENTS[light]] + [r["department"] for r in relevant])),
        "safety":SAFETY,"root_cause_confirmed":False,
        "human_approval_required":True,
        "next_step":"An qualifiziertes Fachteam eskalieren, OEM-Dokumente und Original-DTCs prüfen."
    }
