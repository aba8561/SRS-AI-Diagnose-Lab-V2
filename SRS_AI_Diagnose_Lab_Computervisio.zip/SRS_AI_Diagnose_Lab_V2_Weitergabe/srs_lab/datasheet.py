"""Extracts deliberately simple structured key:value fields from fake text datasheets.
No PDFs, scans, manufacturer documents, or advanced entity extraction are supported.
"""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent.parent
FIELDS={"part_id","nominal_voltage_v","interface","variant","functional_group","document_revision"}
def parse_text(text: str):
    result={}
    for line in text.splitlines():
        if ":" not in line: continue
        key,value=line.split(":",1)
        key=key.strip().lower()
        if key in FIELDS: result[key]=value.strip()
    return result

def datasheet_for(part_id: str):
    if not re.fullmatch(r'DEMO-PART-\d{4}',part_id):return {}
    file=ROOT/"data"/"datasheets_demo"/(part_id+".txt")
    if not file.exists():return {}
    result=parse_text(file.read_text(encoding="utf-8"))
    return result if result.get("part_id")==part_id else {}
