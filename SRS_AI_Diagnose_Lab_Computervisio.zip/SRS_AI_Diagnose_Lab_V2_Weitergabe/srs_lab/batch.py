"""Validated CSV importer for *synthetic* DTC examples. No vehicle interaction."""
import csv
import io
import re
from collections import Counter
from .catalog import COMPONENTS, FAULT_TYPES

COLUMNS = ("code", "component", "type", "status", "occurrences", "ecu", "timestamp", "notes")
REQUIRED = {"code", "component", "type"}
MAX_CSV_BYTES = 120_000
MAX_ROWS = 100
STATUS = {"active", "stored", "intermittent", "unknown"}
CODE_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")

class CsvValidationError(ValueError):
    pass


def parse_dtc_csv(text: str) -> list[dict]:
    if not isinstance(text, str) or not text.strip():
        raise CsvValidationError("CSV ist leer.")
    if len(text.encode('utf-8')) > MAX_CSV_BYTES:
        raise CsvValidationError("CSV ist größer als 120 KB.")
    text = text.lstrip('\ufeff')
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=',;\t')
    except csv.Error:
        dialect = csv.excel
        dialect.delimiter = ';' if text.splitlines()[0].count(';') > text.splitlines()[0].count(',') else ','
    try:
        reader = csv.DictReader(io.StringIO(text, newline=''), dialect=dialect)
        if reader.fieldnames is None:
            raise CsvValidationError('CSV-Kopfzeile fehlt.')
        names = [str(h).strip().lower() for h in reader.fieldnames]
        if len(names) != len(set(names)):
            raise CsvValidationError('Doppelte Spaltennamen sind nicht erlaubt.')
        if not REQUIRED.issubset(set(names)):
            raise CsvValidationError('Erforderliche Spalten: code, component, type.')
        if not set(names).issubset(set(COLUMNS)):
            extras = ', '.join(sorted(set(names) - set(COLUMNS)))
            raise CsvValidationError('Unbekannte Spalten: ' + extras)
        out = []
        for no, r in enumerate(reader, start=2):
            if no > MAX_ROWS + 1:
                raise CsvValidationError(f'Maximal {MAX_ROWS} DTC-Zeilen erlaubt.')
            if None in r:
                raise CsvValidationError(f'Zeile {no}: zu viele Felder.')
            data = {str(k).strip().lower(): (str(v).strip() if v is not None else '') for k,v in r.items()}
            if not any(data.values()):
                continue
            if not CODE_RE.fullmatch(data.get('code','')):
                raise CsvValidationError(f'Zeile {no}: ungültige Demo-Code-ID.')
            if data.get('component','') not in COMPONENTS:
                raise CsvValidationError(f'Zeile {no}: unbekannte Komponenten-ID {data.get("component")!r}.')
            if data.get('type','') not in FAULT_TYPES:
                raise CsvValidationError(f'Zeile {no}: unbekanntes Fehlermuster {data.get("type")!r}.')
            status = data.get('status','unknown').lower() or 'unknown'
            if status not in STATUS:
                raise CsvValidationError(f'Zeile {no}: status muss active, stored, intermittent oder unknown sein.')
            count = data.get('occurrences', '1') or '1'
            if not count.isdigit() or not 1 <= int(count) <= 99999:
                raise CsvValidationError(f'Zeile {no}: occurrences muss 1–99999 sein.')
            for key,limit in [('ecu',60),('timestamp',45),('notes',300)]:
                if len(data.get(key,'')) > limit:
                    raise CsvValidationError(f'Zeile {no}: {key} ist zu lang.')
            out.append({"code":data['code'], "component":data['component'], "type":data['type'],
                        "status":status, "occurrences":int(count),"ecu":data.get('ecu',''),
                        "timestamp":data.get('timestamp',''), "notes":data.get('notes','')})
        if not out:
            raise CsvValidationError('Keine DTC-Zeilen gefunden.')
        return out
    except csv.Error as exc:
        raise CsvValidationError('Ungültiges CSV-Format.') from exc


def summarize_dtcs(entries: list[dict]) -> dict:
    n = len(entries)
    types = Counter(x.get('type','unknown') for x in entries)
    components = Counter(x.get('component','unknown') for x in entries)
    statuses = Counter(x.get('status','unknown') for x in entries)
    # Operational priority only; NOT a component safety assessment or repair instruction.
    return {
        "total":n,
        "active":statuses['active'],
        "stored":statuses['stored'],
        "intermittent":statuses['intermittent'],
        "types":[{"name":k,"count":v} for k,v in types.most_common()],
        "components":[{"name":k,"label":COMPONENTS.get(k,('Unbekannt',''))[0],"count":v} for k,v in components.most_common()],
        "interpretation":"Gezählte synthetische Fehler, keine Bestätigung von Ursachen oder Reparaturen.",
    }
