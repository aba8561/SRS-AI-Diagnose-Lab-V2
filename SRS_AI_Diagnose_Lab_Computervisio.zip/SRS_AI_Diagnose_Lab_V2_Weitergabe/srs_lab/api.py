"""V2 API: structured validation, CSV batch import, auditable report and opt-in LLM."""
import base64
import binascii
import io
from pathlib import Path
from typing import Literal
from PIL import Image, ImageOps, UnidentifiedImageError
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, PlainTextResponse
from pydantic import BaseModel, Field, field_validator
from .agent import run_case
from .vision import predict_image
from .batch import parse_dtc_csv, CsvValidationError, summarize_dtcs
from .catalog import LIGHTS, COMPONENTS, FAULT_TYPES
from .llm import configured, summarize

ROOT=Path(__file__).resolve().parent.parent
app=FastAPI(title='SRS AI Diagnose Lab V2',version='2.0.0',description='Synthetischer Automotive-Lernprototyp, keine Fahrzeugdiagnose')

class VisionInput(BaseModel):
    image_data: str = Field(max_length=1_500_000)

class CsvInput(BaseModel):
    csv_text: str = Field(max_length=120_000)

class DtcInput(BaseModel):
    code: str = Field(min_length=1,max_length=40,pattern=r'^[A-Za-z0-9_-]+$')
    component: str
    type: str
    status: Literal['active','stored','intermittent','unknown']='unknown'
    occurrences: int=Field(default=1,ge=1,le=99999)
    ecu: str=Field(default='',max_length=60)
    timestamp: str=Field(default='',max_length=45)
    notes: str=Field(default='',max_length=300)
    @field_validator('component')
    @classmethod
    def known_component(cls,v):
        if v not in COMPONENTS: raise ValueError('Unbekannte Komponenten-ID.')
        return v
    @field_validator('type')
    @classmethod
    def known_type(cls,v):
        if v not in FAULT_TYPES: raise ValueError('Unbekanntes Fehlermuster.')
        return v

class Config(BaseModel):
    coded: bool | Literal['unknown']='unknown'
    installed: bool | Literal['unknown']='unknown'

class CaseInput(BaseModel):
    light: str='airbag'
    question: str=Field(default='',max_length=1000)
    dtcs: list[DtcInput]=Field(default_factory=list,max_length=100)
    configuration: Config=Field(default_factory=Config)
    include_bom: bool=True
    @field_validator('light')
    @classmethod
    def known_light(cls,v):
        if v not in LIGHTS:raise ValueError('Unbekannte Warnlampe.')
        return v

class LlmInput(BaseModel):
    case: CaseInput

@app.get('/')
def home():
    return FileResponse(ROOT/'static'/'index.html')

@app.get('/api/health')
def health():
    return {'status':'ok','version':'2.0.0','mode':'synthetic_learning',
            'llm_configured':configured(),'cv_real_world_validated':False}

@app.get('/api/catalog')
def catalog():
    return {'lights':LIGHTS,'components':{k:v[0] for k,v in COMPONENTS.items()},
            'fault_types':FAULT_TYPES,'statuses':{'active':'Aktiv','stored':'Gespeichert',
            'intermittent':'Sporadisch','unknown':'Unbekannt'}}

@app.get('/api/example-csv',response_class=PlainTextResponse)
def example_csv():
    return (ROOT/'data'/'demo_24_dtcs.csv').read_text(encoding='utf-8-sig')

@app.get('/examples/{name}')
def examples(name: str):
    allowed={'dashboard_user_reference.png','demo_airbag.png','demo_abs.png',
             'demo_brake.png','demo_engine.png','demo_seatbelt.png','demo_unknown.png'}
    if name not in allowed:raise HTTPException(status_code=404,detail='Beispielbild nicht vorhanden')
    return FileResponse(ROOT/'examples'/name)

@app.post('/api/vision')
def vision(q:VisionInput):
    try:
        raw=base64.b64decode(q.image_data.split(',',1)[-1],validate=True)
        if len(raw)>750_000:raise ValueError('Bild größer als 750 KB')
        with Image.open(io.BytesIO(raw)) as im:
            if im.format not in ('PNG','JPEG','WEBP'):
                raise ValueError('Nur PNG, JPEG oder WEBP erlaubt.')
            im=ImageOps.exif_transpose(im)
            if not (20<=im.width<=2000 and 20<=im.height<=2000):
                raise ValueError('Unzulässige Bildabmessung (20–2000 Pixel).')
            im.load()
            return predict_image(im)
    except (ValueError,binascii.Error,UnidentifiedImageError,OSError,Image.DecompressionBombError) as exc:
        raise HTTPException(400,detail='Bild ungültig: '+str(exc)[:100]) from exc

@app.post('/api/dtcs/parse')
def parse_csv(q:CsvInput):
    try:
        rows=parse_dtc_csv(q.csv_text)
        return {'rows':rows,'summary':summarize_dtcs(rows),'source':'CSV, ausschließlich nutzerbereitgestellte Demo-Daten'}
    except CsvValidationError as exc:
        raise HTTPException(400,detail=str(exc)) from exc

@app.post('/api/analyze')
def analyze(q:CaseInput):
    return run_case(q.light,[d.model_dump() for d in q.dtcs],q.configuration.model_dump(),q.question,q.include_bom)

@app.post('/api/llm')
def llm(q:LlmInput):
    if not configured():
        raise HTTPException(503,detail='LLM optional; Azure OpenAI noch nicht konfiguriert.')
    report=analyze(q.case)
    try:
        return {'text':summarize(report),'source_ids':[x['id'] for x in report['references']],
                'status':'Extern generierter Entwurf, NICHT technisch freigegeben.'}
    except RuntimeError as exc:
        raise HTTPException(502,detail=str(exc)) from exc
