"""Minimal synthetic BOM CSV analysis; prices are fictitious."""
import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def bom_for(component_id: str):
    with (ROOT/"data"/"bom_demo.csv").open(newline="",encoding="utf-8") as f:
        rows=list(csv.DictReader(f))
    found=[x for x in rows if x["component_id"]==component_id]
    return [{"part_id":x["part_id"],"description":x["description"],
             "fictive_eur":float(x["fictional_price_eur"]),"status":"synthetische Stückliste"} for x in found]
