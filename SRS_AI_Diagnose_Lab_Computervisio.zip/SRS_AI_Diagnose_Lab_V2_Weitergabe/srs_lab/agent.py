"""Auditable fixed orchestration. No autonomous repair/coding or remote API calls."""
from .engine import triage
from .retrieval import search
from .bom import bom_for
from .datasheet import datasheet_for
from .batch import summarize_dtcs


def run_case(light, dtcs=None, configuration=None, question='', include_bom=True):
    dtcs = dtcs or []
    trace = ["1. Nutzerbestätigtes Warnlampenlabel übernehmen (Foto beweist keine DTC-Ursache)."]
    r = triage(light, dtcs, configuration)
    r['batch_summary'] = summarize_dtcs(dtcs)
    trace.append(f"2. {len(dtcs)} synthetische DTCs anhand transparenter Regeln untersuchen; keine Fehlerursache bestätigen.")
    refs = search(question, dtcs, 5)
    trace.append("3. Dokumentensuche: TF-IDF + dokumentierte DTC-Metadaten; Quellen sind nur Lehrtexte.")
    bom=[]
    if include_bom:
        for part in dict.fromkeys(d['component_id'] for d in r['dtc_analysis']):
            bom.extend(bom_for(part))
        trace.append("4. Synthetische Komponenten-IDs mit fiktiver BOM und Textdatenblättern verknüpfen.")
    sheets=[datasheet_for(p['part_id']) for p in bom]
    sheets=[x for x in sheets if x]
    trace.append("5. Offene Fragen und Hypothesen an qualifizierte Fachabteilungen übergeben; Freigabe durch Menschen.")
    return {**r, 'references':refs, 'bom':bom, 'datasheets':sheets,
        'trace':trace, 'llm_status':'Nicht verwendet – lokaler Bericht mit transparenten Regeln.',
        'caveat':'Nur simulierte Fälle. Kein Zugang zu OEM-DTC-Daten, kein reparatur- oder zulassungsreifes System.'}
