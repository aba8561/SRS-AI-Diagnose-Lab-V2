﻿@echo off
setlocal
cd /d "%~dp0"
title SRS AI Diagnose Lab V2 - Tests
if not exist ".venv\Scripts\python.exe" (
  echo Die virtuelle Umgebung fehlt. Bitte START_WINDOWS.bat einmal starten.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 (
  echo.
  echo Mindestens ein Test ist fehlgeschlagen.
) else (
  echo.
  echo Testlauf abgeschlossen.
)
pause
