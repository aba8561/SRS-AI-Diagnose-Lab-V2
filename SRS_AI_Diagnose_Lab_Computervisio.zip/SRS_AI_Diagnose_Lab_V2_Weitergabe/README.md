# SRS AI Diagnose Lab V2

**Lokal ausgeführter Prototyp zur strukturierten Auswertung simulierter Warnanzeigen und SRS-Diagnosefälle.**

## Funktionen

- **Bilderkennung:** Klassifikation einzelner Warnsymbole mit einem überwacht trainierten Modell (Logistic Regression); bei unzureichender Zuverlässigkeit keine automatische Festlegung. Die finale Symbolauswahl erfolgt manuell.
- **Fehlerspeicher:** Import von CSV-Daten, formale Prüfung von bis zu 100 Einträgen, Gruppierung nach Bauteil, Fehlerart und Status.
- **Technische Einordnung:** Erklärbare Regelbasis zur Zuordnung von Zuständigkeitsbereichen und möglichen Prüffragen; keine automatische Ursachenbestätigung.
- **Dokumentenverknüpfung:** Suche mit TF-IDF und fachlichen Metadaten sowie Zuordnung zu synthetischen Stücklisten und Textdatenblättern.
- **Bericht:** Strukturierte Ergebnisdarstellung im Browser mit JSON-Export.
- **Optionales LLM:** Adapter für Azure OpenAI zur Textzusammenfassung bei vorhandener Konfiguration; ohne Zugangsdaten deaktiviert.

## Technische Voraussetzungen

- Windows 10/11 und **Python 3.13** (alternativ 3.12 oder 3.11). Getestet wurde Python 3.13.5; Python 3.15 ist für dieses Paket nicht validiert.
- Beim ersten Start Internetzugang zur Installation der Python-Pakete.

**Start:** `START_WINDOWS.bat` im entpackten Ordner doppelklicken. Der Browser wird nach kurzer Verzögerung automatisch geöffnet. Alternativ `http://127.0.0.1:8000` aufrufen. Das Konsolenfenster während der Nutzung geöffnet lassen; mit `Strg+C` beenden.

**Python überprüfen:** `py -3.13 --version`. Fehlt Python 3.13, kann es zusätzlich zu einer anderen installierten Version über die offizielle Python-Distribution installiert werden. Das Startskript bricht mit einer eindeutigen Meldung ab, statt unbemerkt mit Python 3.15 weiterzulaufen.

**Tests separat starten:** `TEST_WINDOWS.bat`; der Testlauf kann auch manuell über `.venv\Scripts\python.exe -m pytest -q` erfolgen.

## Projektstruktur

```text
START_WINDOWS.bat         Windows-Start (mit Versionsprüfung)
TEST_WINDOWS.bat          Testlauf
static/index.html         Browseroberfläche
srs_lab/                  API, Bildmodell, Fehlerspeicher, Dokumentensuche, Bericht
train.py                  Reproduzierbares Training
models/                   Modellartefakt und Metriken
data/                     Synthetische Testfälle, BOM, Textdatenblätter
examples/                 Beispielsymbole und Referenzbild
tests/                    Unit- und API-Tests
.github/workflows/ci.yml  Automatischer Test und Docker-Build
Dockerfile                Lokaler Container-Build
```

## Evaluation und Datenstand

- 1.120 synthetisch erzeugte Symbolbilder, davon 840 für das Training und 280 für den Test; 8 Klassen.
- Die berichteten Accuracy-/F1-Werte von 1,0 gelten ausschließlich für synthetische Bilder aus demselben Generator. Eine belastbare Erkennung realer Cockpitbilder ist **nicht** nachgewiesen.
- 24 vordefinierte Demo-DTCs für den CSV-Durchlauf; zusätzliche generierte Testfälle sind synthetisch. DTC-Kennungen, Bauteil-IDs und Kosten sind keine Herstellerdaten.
- 46 automatisierte Tests in der Referenzumgebung bestanden; das ist keine Garantie für alle Betriebssysteme oder Eingabedaten.
- Ein echter Azure-LLM-Aufruf und produktiver Cloud-Betrieb wurden nicht validiert.

**Entstehung:** Die automotivebezogenen Anwendungsfälle beruhen auf fachlichen Anforderungen aus der Fahrzeugsicherheit; die Softwareumsetzung erfolgte mit KI-gestützter Programmierunterstützung. Konkrete Eigenanteile sollten bei Bedarf getrennt und nachvollziehbar ausgewiesen werden.

**Sicherheit und Datenschutz:** Dieses Paket verarbeitet ausschließlich generierte bzw. vom Anwender bewusst bereitgestellte Eingaben und hat keinen Zugang zu Fahrzeugsteuergeräten. Es enthält keine Original-OEM-Diagnosekataloge. Es dient ausschließlich der Demonstration, **nicht** der realen Diagnose, Reparatur, Codierung oder Sicherheitsfreigabe pyrotechnischer Rückhaltesysteme. Der optionale Cloud-Aufruf muss ausdrücklich aktiviert werden und sollte nur mit dafür freigegebenen Daten erfolgen.
