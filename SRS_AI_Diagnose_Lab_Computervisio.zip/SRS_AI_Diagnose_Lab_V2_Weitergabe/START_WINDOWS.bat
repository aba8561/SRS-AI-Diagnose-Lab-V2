﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title SRS AI Diagnose Lab V2

echo ===============================================
echo SRS AI Diagnose Lab V2
echo Lokal, nur synthetische Testdaten
echo ===============================================
echo.

set "PY="
where py >nul 2>&1
if not errorlevel 1 (
    py -3.13 -V >nul 2>&1
    if not errorlevel 1 set "PY=py -3.13"
)
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3.12 -V >nul 2>&1
        if not errorlevel 1 set "PY=py -3.12"
    )
)
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3.11 -V >nul 2>&1
        if not errorlevel 1 set "PY=py -3.11"
    )
)
if not defined PY (
    where python >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys;sys.exit(0 if sys.version_info[:2] in [(3,11),(3,12),(3,13)] else 1)" >nul 2>&1
        if not errorlevel 1 set "PY=python"
    )
)
if not defined PY goto :nopython

echo Python-Auswahl: %PY%
if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Virtuelle Umgebung erstellen ...
    %PY% -m venv .venv
    if errorlevel 1 goto :error
)
set "ENV_PY=%CD%\.venv\Scripts\python.exe"
"%ENV_PY%" -c "import sys;sys.exit(0 if sys.version_info[:2] in [(3,11),(3,12),(3,13)] else 1)" >nul 2>&1
if errorlevel 1 goto :wrongenv

echo [2/3] Abhaengigkeiten installieren ...
"%ENV_PY%" -m pip install -r requirements.txt
if errorlevel 1 goto :error
if not exist "models\warning_classifier.joblib" (
    echo Modell fehlt, Training wird ausgefuehrt ...
    "%ENV_PY%" train.py
    if errorlevel 1 goto :error
)

echo [3/3] Server starten ...
echo Browseradresse: http://127.0.0.1:8000
echo Zum Beenden: STRG+C
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 3; Start-Process 'http://127.0.0.1:8000'"
"%ENV_PY%" -m uvicorn srs_lab.api:app --host 127.0.0.1 --port 8000
if errorlevel 1 goto :error
exit /b 0

:nopython
echo.
echo FEHLER: Python 3.13 / 3.12 / 3.11 wurde nicht gefunden.
echo Installiere bitte Python 3.13 und starte erneut.
echo Pruefbefehl: py -3.13 --version
pause
exit /b 1

:wrongenv
echo.
echo FEHLER: Die bestehende .venv verwendet die falsche Python-Version.
echo Loesche NUR den Projektordner .venv und starte dann erneut.
pause
exit /b 1

:error
echo.
echo Start nicht erfolgreich. Bitte Fehlermeldung oben beachten.
pause
exit /b 1
