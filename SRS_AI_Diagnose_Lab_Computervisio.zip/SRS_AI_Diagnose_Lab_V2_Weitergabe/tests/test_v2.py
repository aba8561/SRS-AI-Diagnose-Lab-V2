"""V2 regressions: batch import, relevance, safety disclaimers, API and bad inputs."""
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from srs_lab.api import app
from srs_lab.batch import parse_dtc_csv, CsvValidationError, summarize_dtcs
from srs_lab.agent import run_case
from srs_lab.retrieval import search

ROOT=Path(__file__).resolve().parents[1]
client=TestClient(app)
EXAMPLE=(ROOT/'data'/'demo_24_dtcs.csv').read_text(encoding='utf-8-sig')


def test_example_csv_24_valid():
    rows=parse_dtc_csv(EXAMPLE)
    assert len(rows)==24
    assert rows[0]['component']=='driver_knee_airbag'
    assert sum(x['status']=='active' for x in rows)>0


def test_csv_semicolon_comma_and_utf8_bom():
    cols='code;component;type;status\n'
    row='DEMO-001;driver_knee_airbag;resistance_high;active\n'
    assert parse_dtc_csv('\ufeff'+cols+row)[0]['status']=='active'
    assert parse_dtc_csv((cols+row).replace(';',','))[0]['type']=='resistance_high'


@pytest.mark.parametrize('bad',[
    '', 'code,component\nX,driver_knee_airbag',
    'code;component;type\nFOO;bad_component;resistance_high',
    'code;component;type\nFOO;driver_knee_airbag;unlisted',
    'code;component;type;status\nFOO;driver_knee_airbag;resistance_high;repaired',
    'code;component;type;occurrences\nFOO;driver_knee_airbag;resistance_high;0',
    'code;component;type;notes\nFOO;driver_knee_airbag;resistance_high;"a;b";extra',
    'code,component,type\n=HACK,driver_knee_airbag,resistance_high',
])
def test_invalid_csv_rejected(bad):
    with pytest.raises(CsvValidationError):parse_dtc_csv(bad)


def test_too_many_rows_rejected():
    lines=['code;component;type']+[f'DEMO-{i};driver_knee_airbag;resistance_high' for i in range(101)]
    with pytest.raises(CsvValidationError,match='Maximal'):
        parse_dtc_csv('\n'.join(lines))


def test_batch_summary_types_and_statuses():
    rows=parse_dtc_csv(EXAMPLE)
    x=summarize_dtcs(rows)
    assert x['total']==24
    assert x['active']+x['stored']+x['intermittent']==24
    assert sum(t['count'] for t in x['types'])==24


@pytest.mark.parametrize('question,kind,doc_id',[
    ('Was bedeutet Widerstand zu hoch am Knieairbag?', 'resistance_high','DEMO-RES-HIGH'),
    ('Widerstand zu niedrig / Kurzschluss im Gurtstraffer?', 'resistance_low','DEMO-RES-LOW'),
    ('ZDC und invalid dataset nach Softwareupdate', 'invalid_dataset','DEMO-DATASET'),
    ('Codierabweichung Fahrzeugausstattung', 'coding_mismatch','DEMO-VARIANT'),
    ('CAN timeout Kommunikationsabbruch', 'communication_timeout','DEMO-NETWORK'),
    ('Unterspannung Bordnetz Airbag', 'voltage_low','DEMO-VOLT-LOW'),
    ('sporadischer DTC in Messung', 'intermittent','DEMO-SPORADIC'),
])
def test_retrieval_most_relevant(question,kind,doc_id):
    refs=search(question,[{'type':kind,'component':'driver_knee_airbag'}])
    assert refs and refs[0]['id']==doc_id,[(r['id'],r['score']) for r in refs]


def test_batch_24_engine_hypotheses_are_not_repairs():
    rows=parse_dtc_csv(EXAMPLE)
    r=run_case('airbag',rows,{},'Welche Probleme müssen geprüft werden?',True)
    assert r['batch_summary']['total']==24
    assert len(r['dtc_analysis'])==24
    assert r['root_cause_confirmed'] is False
    assert r['human_approval_required'] is True
    assert all(d['needs_oem_definition'] for d in r['dtc_analysis'])
    assert r['references']
    assert len(r['bom'])<=len(rows)


def test_high_resistance_is_not_coding_proof():
    dtc={'code':'DEMO-17','component':'driver_knee_airbag','type':'resistance_high'}
    r=run_case('airbag',[dtc],{'coded':True,'installed':False},'widerstand hoch')
    notes=' '.join(e['finding'] for e in r['dtc_analysis'][0]['evidence']).lower()
    assert 'denkbar' in notes and 'mögliche' in notes
    assert r['root_cause_confirmed'] is False


def test_health_exposes_limitations():
    r=client.get('/api/health')
    assert r.status_code==200
    assert r.json()['cv_real_world_validated'] is False


def test_api_catalog_and_home():
    assert client.get('/').status_code==200
    assert 'driver_knee_airbag' in client.get('/api/catalog').json()['components']


def test_api_example_csv_roundtrip():
    c=client.get('/api/example-csv')
    assert c.status_code==200
    r=client.post('/api/dtcs/parse',json={'csv_text':c.text})
    assert r.status_code==200
    assert len(r.json()['rows'])==24


def test_api_rejects_bad_csv():
    resp=client.post('/api/dtcs/parse',json={'csv_text':'hi'})
    assert resp.status_code==400


def test_api_batch_analyze_24():
    rows=parse_dtc_csv(EXAMPLE)
    r=client.post('/api/analyze',json={'light':'airbag','dtcs':rows,'question':'Fehleranalyse','include_bom':True})
    assert r.status_code==200,r.text[:300]
    data=r.json()
    assert data['batch_summary']['total']==24
    assert data['human_approval_required']
    assert data['references'][0]['source_kind'].startswith('Synthetisches')


def test_api_rejects_unknown_component():
    r=client.post('/api/analyze',json={'light':'airbag','dtcs':[{'code':'DEMO-1','component':'bad','type':'resistance_high'}]})
    assert r.status_code==422


def test_api_rejects_non_img():
    r=client.post('/api/vision',json={'image_data':'data:image/png;base64,YWJjZA=='})
    assert r.status_code==400


def test_vision_does_not_claim_real_validation():
    import base64
    b=base64.b64encode((ROOT/'examples'/'demo_airbag.png').read_bytes()).decode()
    r=client.post('/api/vision',json={'image_data':'data:image/png;base64,'+b})
    assert r.status_code==200,r.text
    d=r.json()
    assert d['human_confirmation_required'] is True
    assert d['real_image_accuracy_validated'] is False


def test_llm_without_credentials_is_explicit(monkeypatch):
    for key in ('AZURE_OPENAI_API_KEY','AZURE_OPENAI_ENDPOINT','AZURE_OPENAI_DEPLOYMENT'):
        monkeypatch.delenv(key,raising=False)
    r=client.post('/api/llm',json={'case':{'light':'airbag','dtcs':[]}})
    assert r.status_code==503
    assert 'nicht konfiguriert' in r.json()['detail']
