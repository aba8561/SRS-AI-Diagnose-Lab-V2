from srs_lab.engine import triage,classify_dtc
from srs_lab.agent import run_case
from srs_lab.retrieval import search
from srs_lab.bom import bom_for

def test_airbag_routes_to_safety():
 r=triage("airbag",[])
 assert "Fahrzeugsicherheit" in r["routing"]
 assert r["root_cause_confirmed"] is False
 assert r["human_approval_required"] is True

def test_high_resistance_never_certain():
 r=classify_dtc({"component":"driver_front_airbag","type":"resistance_high"})
 assert all(e["confidence"]!="Sicher" for e in r["evidence"])
 assert "Unterbrechung" in r["evidence"][0]["finding"]

def test_coding_hint_conditional():
 r=classify_dtc({"component":"driver_knee_airbag","type":"resistance_high"},{"coded":True,"installed":False})
 assert len(r["evidence"])==2
 assert "Konfigurationsabweichung" in r["evidence"][1]["finding"]

def test_low_resistance_doesnt_mean_uncoded():
 r=classify_dtc({"component":"driver_front_airbag","type":"resistance_low"})
 assert len(r["evidence"])==1
 assert "Kurzschluss" in r["evidence"][0]["finding"]

def test_invalid_dataset():
 r=classify_dtc({"component":"srs_control_unit","type":"invalid_dataset"})
 assert "Zieldatencontainer" in r["evidence"][0]["action"]

def test_unknown_fault_does_not_invent():
 r=classify_dtc({"component":"blorp","type":"unmapped"})
 assert r["needs_oem_definition"] is True
 assert "Kein belastbarer" in r["evidence"][0]["finding"]

def test_retrieval_works():
 assert any("Datensatz" in x["title"] for x in search("ZDC Datensatz ungültig",k=3))

def test_bom_fiction():
 assert all("DEMO" in b["part_id"] for b in bom_for("driver_front_airbag"))

def test_agent_trace():
 r=run_case("airbag",[{"code":"DEMO-1","type":"resistance_high","component":"driver_front_airbag"}],include_bom=True)
 assert r["references"] and r["bom"] and len(r["trace"])==5
 assert "Nicht verwendet" in r["llm_status"]

def test_ecall_separate_department():
 r=triage("airbag",[{"component":"ecall_module","type":"communication_timeout"}])
 assert any("Telematik" in s for s in r["departments"])


def test_structured_datasheet_extraction():
 from srs_lab.datasheet import datasheet_for,parse_text
 r=datasheet_for("DEMO-PART-0001")
 assert r["part_id"] == "DEMO-PART-0001"
 assert r["document_revision"].startswith("DEMO-R")
 assert parse_text("unknown: x\npart_id: TEST") == {"part_id":"TEST"}
