from fastapi.testclient import TestClient
from srs_lab.api import app

client=TestClient(app)
def test_health():
 assert client.get('/api/health').json()['status']=='ok'
def test_catalog():
 assert 'driver_knee_airbag' in client.get('/api/catalog').json()['components']
def test_analyze():
 r=client.post('/api/analyze',json={'light':'airbag','dtcs':[{'code':'DEMO-A','type':'invalid_dataset','component':'srs_control_unit'}]})
 assert r.status_code==200
 assert r.json()['root_cause_confirmed'] is False
def test_reject_invalid_image():
 r=client.post('/api/vision',json={'image_data':'not-base64'})
 assert r.status_code==400


def test_valid_ml_image():
 import io,base64
 from srs_lab.vision import make_symbol
 buf=io.BytesIO();make_symbol('abs',10002).save(buf,format='PNG')
 r=client.post('/api/vision',json={'image_data':'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode('ascii')})
 assert r.status_code == 200
 assert 'confidence' in r.json()
